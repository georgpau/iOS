//
//  EventDetailsViewController.swift
//  NewCapstone1
//
//  Created by Xcode User on 2017-09-19.
//  Copyright © 2017 Xcode User. All rights reserved.
//

import UIKit

class EventDetailsViewController: UIViewController {
    
    
    @IBOutlet weak var lblName: UILabel?
    @IBOutlet weak var txtDescription:UITextView?
    @IBOutlet weak var lblLocation:UILabel?
    @IBOutlet weak var lblTime:UILabel?
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    
    
    @IBAction func unwindtoThisViewController(segue:UIStoryboardSegue){
        
    }
    
    @IBAction func register(sender: UIButton){
        
        
        let url = NSURL(string: "http://capstoneprototypeqci.azurewebsites.net/api/EventsAPI/1") //Remember to put ATS exception if the URL is not https
        let request = NSMutableURLRequest(url: url! as URL)
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type") //Optional
        request.httpMethod = "PUT"
        let session = URLSession(configuration:URLSessionConfiguration.default, delegate: nil, delegateQueue: nil)
        let data = "username=self@gmail.com&password=password".data(using: String.Encoding.utf8)
        request.httpBody = data
        
        let dataTask = session.dataTask(with: request as URLRequest) { (data, response, error) -> Void in
            
            if error != nil {
                
                print("error thrown");
            }
            else {
                
                let jsonStr = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                print("Parsed JSON: '\(jsonStr)'")
            } 
        }
        dataTask.resume()
        
        
        
        let refreshAlert = UIAlertController(title: "Success", message: "You have registered successfully.", preferredStyle: UIAlertControllerStyle.alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
            print("Handle Ok logic here")
        }))
        
        present(refreshAlert, animated: true, completion: nil)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lblName?.text=appDelegate.eventName
        self.txtDescription?.text=appDelegate.eventDescription;
        self.lblLocation?.text=appDelegate.eventLocation;
        lblTime?.text=appDelegate.eventTime;

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
